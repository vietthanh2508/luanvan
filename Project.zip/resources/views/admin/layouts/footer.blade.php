<footer class="main-footer">
  <!-- To the right -->
  <div class="pull-right hidden-xs">
    <b>AdminLTE</b> 2.4.18
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2023 <a href="#"></a>.</strong> All rights reserved.
</footer>

<?php

  return [
    'AboutUs'          =>      'Về Chúng Tôi',
    'address'          =>      'Số 1 Đại Cồ Việt, Bách Khoa, Hai Bà Trưng, Hà Nội.',
    'FollowUs'         =>      'Theo Dõi Chúng Tôi',
    'visa'             =>      'Thanh toán bằng thẻ Visa.',
    'mastercard'       =>      'Thanh toán bằng thẻ MasterCard.',
    'jcb'              =>      'Thanh toán bằng thẻ JCB.',
    'cod'              =>      'Thanh toán khi nhận hàng.',
    'nganluong'        =>      'Giải pháp thanh toán qua Ngân Lượng.',
    'payment'          =>      'Hỗ Trợ Thanh Toán',
    'support'          =>      'Hỗ Trợ Khách Hàng',
  ];

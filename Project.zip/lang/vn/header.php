<?php

return [

    'Home'          =>       'Trang Chủ',
    'About'         =>       'Giới Thiệu',
    'Products'      =>       'Sản Phẩm',
    'News'          =>       'Tin Tức',
    'Contact'       =>       'Liên Hệ',
    'Login'         =>       'Đăng Nhập',
    'Logout'        =>       'Đăng Xuất',
    'Register'      =>       'Đăng Ký',
    'Search'        =>       'Tìm Kiếm...',
    'Producer'      =>       'Hãng Sản Xuất',

];

<?php
  return [
    'title'                 =>          'Đăng kí tài khoản',
    'social.title'          =>          'Đăng kí bằng tài khoản',
    'form.title'            =>          'Hoặc đăng kí trực tiếp',
    'fullname'              =>          'Họ và Tên',
    'email'                 =>          'Địa chỉ Email',
    'phone'                 =>          'Số điện thoại',
    'password'              =>          'Mật khẩu',
    'password-confirm'      =>          'Xác nhận lại mật khẩu',
  ];

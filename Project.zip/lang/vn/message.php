<?php

  return [
    'welcome'       =>      'Phone Store kính chào quý khách!',
  ];

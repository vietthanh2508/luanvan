<?php
  return [
    'title'                 =>          'Register Account',
    'social.title'          =>          'Register with account',
    'form.title'            =>          'Or register using the form',
    'fullname'              =>          'Full Name',
    'email'                 =>          'E-Mail Address',
    'phone'                 =>          'Phone Number',
    'password'              =>          'Password',
    'password-confirm'      =>          'Confirm Password',
  ];

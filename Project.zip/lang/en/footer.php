<?php

  return [
    'AboutUs'          =>      'About Us',
    'address'          =>      'No.1 Dai Co Viet, Bach Khoa, Hai Ba Trung, Hanoi.',
    'FollowUs'         =>      'Follow Us',
    'visa'             =>      'Visa method',
    'mastercard'       =>      'MasterCard method',
    'jcb'              =>      'JCB method',
    'cod'              =>      'Cash on Delivery - COD.',
    'nganluong'        =>      'Provided by NganLuong.',
    'payment'          =>      'Payment Method',
    'support'          =>      'Customer Support',
  ];

<?php

  return [
    'Home'          =>      'Home',
    'About'         =>      'About',
    'Products'      =>      'Products',
    'News'          =>      'News',
    'Contact'       =>      'Contact',
    'Login'         =>      'Login',
    'Logout'        =>      'Logout',
    'Register'      =>      'Register',
    'Search'        =>      'Search...',
    'Producer'      =>      'Producers',
  ];

<?php

  return [
    'welcome'       =>      'Welcome to Phone Store!',
  ];

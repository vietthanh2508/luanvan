<?php $__env->startSection('title', 'Đơn Hàng: #'.$order->order_code); ?>

<?php $__env->startSection('embed-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="<?php echo e(route('admin.order.index')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i> Quản Lý Đơn Hàng</a></li>
  <li class="active"><?php echo e('Đơn Hàng: #'.$order->order_code); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Main content -->
  <section class="invoice" style="margin: 0;">
    <div id="print-invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <div style="display: inline-flex; align-items: center;">
              <div style="width: 30px; margin-right: 5px;">
                <img src="<?php echo e(asset('images/favicon.png')); ?>" alt="PhoneStore Logo" style="width: 100%; height: auto; object-fit: cover;">
              </div>
              <div style="color: #f33;">VDO</div>
            </div>
            <small class="pull-right">Date: <?php echo e(date("d/m/Y")); ?></small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="invoice-info">
        <div class="row">
          <div class="col-md-3 col-sm-3 col-xs-3">
            From: <br>
            <br>
            <address>
              <b>Admin VDO</b><br>
              Phone: (+84) 343 754 517<br>
              Email: thanhtrung@gmail.com<br>
              Address: Đinh Bộ Lĩnh - P 25 - Bình Thạnh.
            </address>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-3">
            To: <br>
            <br>
            <address>
              <b><?php echo e($order->name); ?></b><br>
              Phone: <?php echo e($order->phone); ?><br>
              Email: <?php echo e($order->email); ?><br>
              Address: <?php echo e($order->address); ?>

            </address>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-3">
            Thông Tin Tài Khoản<br>
            <br>
            <address>
              <b><?php echo e($order->user->name); ?></b><br>
              Phone: <?php echo e($order->user->phone); ?><br>
              Email: <?php echo e($order->user->email); ?><br>
              Address: <?php echo e($order->user->address); ?>

            </address>
          </div>
          <div class="col-md-3 col-sm-3 col-xs-3">
            Thông Tin Đơn Hàng<br>
            <br>
            <address>
              <b>Đơn Hàng #<?php echo e($order->order_code); ?></b><br>
              <b>Ngày Tạo:</b> <?php echo e(date_format($order->created_at, 'd/m/Y')); ?><br>
              <b>Thanh Toán:</b> <?php echo e($order->payment_method->name); ?>

            </address>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th style="text-align: center;">STT</th>
                <th>Mã Sản Phẩm</th>
                <th>Tên Sản Phẩm</th>
                <th>Mầu Sắc</th>
                <th style="text-align: center;">Số Lượng</th>
                <th>Đơn Giá</th>
                <th>Tổng Tiền</th>
              </tr>
            </thead>
            <tbody>
              <?php $price = 0; ?>
              <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $price = $price + $order_detail->price * $order_detail->quantity; ?>
                <tr>
                  <td style="text-align: center;"><?php echo e($key + 1); ?></td>
                  <td><?php echo e('#'.$order_detail->product_detail->product->sku_code); ?></td>
                  <td><?php echo e($order_detail->product_detail->product->name); ?></td>
                  <td><?php echo e($order_detail->product_detail->color); ?></td>
                  <td style="text-align: center;"><?php echo e($order_detail->quantity); ?></td>
                  <td><span style="color: #f30;"><?php echo e(number_format($order_detail->price,0,',','.')); ?> VNĐ</span></td>
                  <td><span style="color: #f30;"><?php echo e(number_format($order_detail->price * $order_detail->quantity,0,',','.')); ?> VNĐ</span></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td colspan="7" style="text-align: right;"><b>Tổng = <span style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?> VNĐ</span></b></td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <p class="lead">Phương Thức Thanh Toán:</p>
          <?php if(Str::contains($order->payment_method->name, 'Online Payment')): ?>
            <div style="width: fit-content; padding: 5px; border: 1px solid #e3e3e3; border-radius: 5px; box-shadow: 0px 0px 5px #e3e3e3;">
              <img style="width: 150px; height: 50px; object-fit: cover;" src="<?php echo e(asset('images/nganluong.png')); ?>" alt="Ngân Lượng">
            </div>
          <?php else: ?>
            <div style="width: fit-content; padding: 5px; border: 1px solid #e3e3e3; border-radius: 5px; box-shadow: 0px 0px 5px #e3e3e3;">
              <img style="width: 150px; height: 60px; object-fit: cover;" src="<?php echo e(asset('images/cod.png')); ?>" alt="COD">
            </div>
          <?php endif; ?>

          <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
            <b><?php echo e($order->payment_method->name.':'); ?></b><br>
            <span style="margin-left: 15px;"><?php echo e($order->payment_method->describe); ?></span>
          </p>
        </div>
        <!-- /.col -->
        <div class="col-xs-6">
          <p class="lead">Thanh Toán Chi Tiết</p>

          <div class="table-responsive">
            <table class="table">
              <tr>
                <th style="width:50%">Tổng Tiền:</th>
                <td><span style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?> VNĐ</span></td>
              </tr>
              <tr>
                <th>Đã Thanh Toán:</th>
                <?php if(Str::contains($order->payment_method->name, 'Online Payment')): ?>
                <td><span style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?> VNĐ</span></td>
                <?php else: ?>
                <td><span style="color: #f30;">0 VNĐ</span></td>
                <?php endif; ?>
              </tr>
              <tr>
                <th>Phí Vận Chuyển:</th>
                <td><span style="color: #f30;">0 VNĐ</span></td>
              </tr>
              <tr>
                <th>Tổng Số Tiền Phải Thanh Toán:</th>
                <?php if(Str::contains($order->payment_method->name, 'Online Payment')): ?>
                <td><span style="color: #f30;">0 VNĐ</span></td>
                <?php else: ?>
                <td><span style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?> VNĐ</span></td>
                <?php endif; ?>
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- this row will not appear when printing -->
    <div class="row no-print">
      <div class="col-xs-12">
        <button class="btn btn-success btn-print pull-right"><i class="fa fa-print"></i> In Hóa Đơn</button>
      </div>
    </div>
  </section>
  <!-- /.content -->
  <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('embed-js'); ?>
<!-- Print JS -->
<script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script>
  $(document).ready(function() {
    $('.btn-print').click(function(){
      printJS({
        printable: 'print-invoice',
        type: 'html',
        css: [
          '<?php echo e(asset('AdminLTE/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>',
          '<?php echo e(asset('AdminLTE/dist/css/AdminLTE.min.css')); ?>'
        ],
        style: 'img { filter: grayscale(100%); -webkit-filter: grayscale(100%); }'
      });
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/admin/order/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('embed-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="<?php echo e(route('admin.users')); ?>"><i class="fa fa-users"></i> Quản Lý Tài Khoản</a></li>
  <li class="active"><?php echo e($user->name); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-3">

    <!-- Profile Image -->
    <div class="box box-primary">
      <div class="box-body box-profile">
        <img class="profile-user-img img-responsive img-circle" src="<?php echo e(Helper::get_image_avatar_url($user->avatar_image)); ?>" alt="User profile picture">

        <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>

        <?php if($user->active): ?>
        <p class="text-center"><span class="label label-success">Activated</span></p>
        <?php else: ?>
        <p class="text-center"><span class="label label-danger">Not Activated</span></p>
        <?php endif; ?>

        <ul class="list-group list-group-unbordered">
          <li class="list-group-item">
            <b>Email</b> <a class="pull-right"><?php echo e($user->email); ?></a>
          </li>
          <li class="list-group-item">
            <b>Số điện thoại</b> <a class="pull-right"><?php echo e($user->phone); ?></a>
          </li>
          <li class="list-group-item">
            <b>Liên kết tài khoản</b> <a class="pull-right"><?php echo e($user->provider ?: 'Không'); ?></a>
          </li>
          <li class="list-group-item">
            <b>Ngày tạo</b> <a class="pull-right"><?php echo e(date_format($user->created_at, 'd/m/Y')); ?></a>
          </li>
        </ul>
        <strong><i class="fa fa-map-marker margin-r-5"></i> Địa chỉ</strong>
        <p class="text-muted"><?php echo e($user->address); ?></p>
        <?php if(!$user->active): ?>
        <a href="<?php echo e(route('admin.user_send', ['id' => $user->id])); ?>" class="btn btn-warning btn-block"><b>Send Active Account</b></a>
        <?php endif; ?>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <!-- /.col -->
  <div class="col-md-9">
    <div class="nav-tabs-custom">
      <ul class="nav nav-tabs">
        <li class="active"><a href="#comment-timeline" data-toggle="tab">Lịch Sử Bình Luận</a></li>
        <li><a href="#order-timeline" data-toggle="tab">Lịch Sử Mua Hàng</a></li>
      </ul>
      <div class="tab-content">
        <div class="active tab-pane" id="comment-timeline">
          <?php if($product_votes->isNotEmpty()): ?>
          <!-- The timeline -->
          <ul class="timeline timeline-inverse">
            <?php $__currentLoopData = $product_votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- timeline time label -->
              <li class="time-label">
                <span class="bg-red">
                  <i class="fa fa-clock-o"></i> <?php echo e(date_format($vote->created_at, 'H:i d/m/Y')); ?>

                </span>
              </li>
              <!-- /.timeline-label -->
              <!-- timeline item -->
              <li>
                <i class="fa fa-comments bg-blue" aria-hidden="true"></i>

                <div class="timeline-item">

                  <h3 class="timeline-header"><a><?php echo e($user->name); ?></a> đã đánh giá <a><?php echo e($vote->rate); ?></a> sao về sản phẩm <a><?php echo e($vote->product->name); ?></a></h3>

                  <div class="timeline-body">
                    <b>Nội Dung:</b> <?php echo e($vote->content); ?>

                  </div>
                  <div class="timeline-footer">
                    <span class="label label-warning"><?php echo e($vote->rate); ?> Sao</span>
                  </div>
                </div>
              </li>
              <!-- END timeline item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li>
              <i class="fa fa-clock-o bg-gray"></i>
            </li>
          </ul>
          <?php else: ?>
          <div style="width: 100%; padding-top: 30%; position: relative;">
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 20px;">Lịch Sử Bình Luận Trống!</div>
          </div>
          <?php endif; ?>
        </div>
        <!-- /.tab-pane -->

        <div class="tab-pane" id="order-timeline">
          <?php if($orders->isNotEmpty()): ?>
          <!-- The timeline -->
          <ul class="timeline timeline-inverse">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php
                $qty = 0;
                $price = 0;
                foreach($order->order_details as $order_detail) {
                  $qty = $qty + $order_detail->quantity;
                  $price = $price + $order_detail->price * $order_detail->quantity;
                }
              ?>
              <!-- timeline time label -->
              <li class="time-label">
                <span class="bg-yellow">
                  <i class="fa fa-clock-o"></i> <?php echo e(date_format($order->created_at, 'H:i d/m/Y')); ?>

                </span>
              </li>
              <!-- /.timeline-label -->
              <!-- timeline item -->
              <li>
                <?php if($order->status): ?>
                <i class="fa fa-check bg-green" aria-hidden="true"></i>
                <?php else: ?>
                <i class="fa fa-times bg-red" aria-hidden="true"></i>
                <?php endif; ?>

                <div class="timeline-item">

                  <h3 class="timeline-header"><a><?php echo e($user->name); ?></a> đã mua <b style="color: #f30;"><?php echo e($qty); ?></b> sản phẩm với giá trị <b style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?></b> VNĐ</h3>

                  <div class="timeline-body">
                    <div class="table-responsive">
                      <table class="table table-striped" style="margin-bottom: 0; background-color: #fff;">
                        <thead>
                          <tr>
                            <th class="text-center" style="vertical-align: middle;">STT</th>
                            <th class="text-center" style="vertical-align: middle;">Mã<br>Sản Phẩm</th>
                            <th class="text-center" style="vertical-align: middle;">Tên<br>Sản Phẩm</th>
                            <th class="text-center" style="vertical-align: middle;">Mầu Sắc</th>
                            <th class="text-center" style="vertical-align: middle;">Số Lượng</th>
                            <th class="text-center" style="vertical-align: middle;">Đơn Giá</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td class="text-center" style="vertical-align: middle;"><?php echo e($key + 1); ?></td>
                              <td class="text-center" style="vertical-align: middle;"><a title="<?php echo e($order_detail->product_detail->product->name); ?>"><?php echo e($order_detail->product_detail->product->sku_code); ?></a></td>
                              <td class="text-center" style="vertical-align: middle;"><?php echo e($order_detail->product_detail->product->name); ?></td>
                              <td class="text-center" style="vertical-align: middle;"><?php echo e($order_detail->product_detail->color); ?></td>
                              <td class="text-center" style="vertical-align: middle;"><?php echo e($order_detail->quantity); ?></td>
                              <td class="text-center" style="color: #f30; vertical-align: middle;"><?php echo e(number_format($order_detail->price,0,',','.')); ?>₫</td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="timeline-footer">
                    <?php if($order->status): ?>
                    <span class="label label-success">Thành Công</span>
                    <?php else: ?>
                    <span class="label label-danger">Thất Bại</span>
                    <?php endif; ?>
                  </div>
                </div>
              </li>
              <!-- END timeline item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li>
              <i class="fa fa-clock-o bg-gray"></i>
            </li>
          </ul>
          <?php else: ?>
          <div style="width: 100%; padding-top: 30%; position: relative;">
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 20px;">Lịch Sử Mua Hàng Trống!</div>
          </div>
          <?php endif; ?>
        </div>
        <!-- /.tab-pane -->
      </div>
      <!-- /.tab-content -->
    </div>
    <!-- /.nav-tabs-custom -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('embed-js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/admin/user/show.blade.php ENDPATH**/ ?>
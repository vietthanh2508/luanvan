<?php $__env->startSection('title', 'Quên Mật Khẩu'); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('header.Home')); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page">Quên Mật Khẩu</li>
      </ol>
    </nav>
  </section>

  <div class="site-login">
      <div class="login-body">
        <h2 class="title">Quên Mật Khẩu</h2>
        <form action="<?php echo e(route('password.email')); ?>" method="POST" accept-charset="utf-8">
          <?php echo csrf_field(); ?>

          <?php if(session('message')): ?>
            <div class="form_message">
              <?php echo e(session('message')); ?>

            </div>
          <?php endif; ?>

          <div class="input-group">
            <span class="input-group-addon"><i class="fas fa-envelope"></i></span>
            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <button type="submit" class="btn btn-default">Xác Nhận</button>
        </form>
      </div>

      <div class="sign-up-now">
        Not a member? <a href="<?php echo e(route('register')); ?>">Sign up now</a>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){
      <?php if(session('alert')): ?>
        Swal.fire(
          '<?php echo e(session('alert')['title']); ?>',
          '<?php echo e(session('alert')['content']); ?>',
          '<?php echo e(session('alert')['type']); ?>'
        )
      <?php endif; ?>
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $data['order']->order_code); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('Trang Chủ')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('orders_page')); ?>">Đơn Hàng</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($data['order']->order_code); ?></li>
      </ol>
    </nav>
  </section>

  <div class="site-order">
    <section class="section-advertise">
      <div class="content-advertise">
        <div id="slide-advertise" class="owl-carousel">
          <?php $__currentLoopData = $data['advertises']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide-advertise-inner" style="background-image: url('<?php echo e(Helper::get_image_advertise_url($advertise->image)); ?>');" data-dot="<button><?php echo e($advertise->title); ?></button>"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

    <?php
      $qty = 0;
      $price = 0;
      foreach($data['order']->order_details as $order_detail) {
        $qty = $qty + $order_detail->quantity;
        $price = $price + $order_detail->price * $order_detail->quantity;
      }
    ?>

    <section class="section-order">
      <div class="section-header">
        <div class="section-header-left">
          <h2 class="section-title"><?php echo e($data['order']->order_code); ?> <span>( <?php echo e($qty); ?> sản phẩm)</span></h2>
        </div>
        <div class="section-header-right">
          Ngày tạo: <?php echo e(date_format($data['order']->created_at, 'd/m/Y')); ?>

        </div>
      </div>
      <div class="section-content">
        <div class="row">
          <div class="col-md-9">
            <div class="order-info">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="order-info-left">
                    <div class="order-info-header">
                      <h3 class="text-center">Thông Tin Tài Khoản</h3>
                    </div>
                    <div class="order-info-content">
                      <div><span>Tên</span> <span><?php echo e($data['order']->user->name); ?></span></div>
                      <div><span>Email</span> <span><?php echo e($data['order']->user->email); ?></span></div>
                      <div><span>Số Điện Thoại</span> <span><?php echo e($data['order']->user->phone); ?></span></div>
                      <div><span>Địa Chỉ</span> <span><?php echo e($data['order']->user->address); ?></span></div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="order-info-right">
                    <div class="order-info-header">
                      <h3 class="text-center">Thông Tin Mua Hàng</h3>
                    </div>
                    <div class="order-info-content">
                      <div><span>Tên</span> <span><?php echo e($data['order']->name); ?></span></div>
                      <div><span>Email</span> <span><?php echo e($data['order']->email); ?></span></div>
                      <div><span>Số Điện Thoại</span> <span><?php echo e($data['order']->phone); ?></span></div>
                      <div><span>Địa Chỉ</span> <span><?php echo e($data['order']->address); ?></span></div>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="order-info-center">
                    <div class="order-info-header">
                      <h3 class="text-center">Thông Tin Đơn Hàng</h3>
                    </div>
                    <div class="order-info-content">
                      <div><span>Mã Hóa Đơn</span> <span><?php echo e($data['order']->order_code); ?></span></div>
                      <div><span>Phương Thức Thanh Toán</span> <span><?php echo e($data['order']->payment_method->name); ?></span></div>
                      <div><span>Số Lượng</span> <span><?php echo e($qty); ?> sản phẩm</span></div>
                      <div><span>Đơn giá</span> <span style="color: #f30;"><?php echo e(number_format($price,0,',','.')); ?>₫</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="order-table">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th class="text-center">STT</th>
                      <th class="text-center">Mã<br>Sản Phẩm</th>
                      <th class="text-center">Tên<br>Sản Phẩm</th>
                      <th class="text-center">Mầu Sắc</th>
                      <th class="text-center">Số Lượng</th>
                      <th class="text-center">Đơn Giá</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $data['order']->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="text-center"><?php echo e($key + 1); ?></td>
                        <td class="text-center"><a href="<?php echo e(route('product_page', ['id' => $order_detail->product_detail->product->id])); ?>" title="<?php echo e($order_detail->product_detail->product->name); ?>"><?php echo e($order_detail->product_detail->product->sku_code); ?></a></td>
                        <td class="text-center"><?php echo e($order_detail->product_detail->product->name); ?></td>
                        <td class="text-center"><?php echo e($order_detail->product_detail->color); ?></td>
                        <td class="text-center"><?php echo e($order_detail->quantity); ?></td>
                        <td class="text-center" style="color: #f30;"><?php echo e(number_format($order_detail->price,0,',','.')); ?>₫</td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="online_support">
              <h2 class="title">CHÚNG TÔI LUÔN SẴN SÀNG<br>ĐỂ GIÚP ĐỠ BẠN</h2>
              <img src="<?php echo e(asset('images/support_online.jpg')); ?>">
              <h3 class="sub_title">Để được hỗ trợ tốt nhất. Hãy gọi</h3>
              <div class="phone">
                <a href="tel:18006750" title="1800 6750">1800 6750</a>
              </div>
              <div class="or"><span>HOẶC</span></div>
              <h3 class="title">Chat hỗ trợ trực tuyến</h3>
              <h3 class="sub_title">Chúng tôi luôn trực tuyến 24/7.</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>
    .slide-advertise-inner {
      background-repeat: no-repeat;
      background-size: cover;
      padding-top: 21.25%;
    }
    #slide-advertise.owl-carousel .owl-item.active {
      -webkit-animation-name: zoomIn;
      animation-name: zoomIn;
      -webkit-animation-duration: .6s;
      animation-duration: .6s;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){

      $("#slide-advertise").owlCarousel({
        items: 2,
        autoplay: true,
        loop: true,
        margin: 10,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        responsive:{
          0:{
            items: 1,
          },
          992:{
            items: 2,
            animateOut: 'zoomInRight',
            animateIn: 'zoomOutLeft',
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>']
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/pages/order.blade.php ENDPATH**/ ?>
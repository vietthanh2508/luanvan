<?php $__env->startSection('title', 'Kho Hàng'); ?>

<?php $__env->startSection('embed-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>
<style>
  #product-table td,
  #product-table th {
    vertical-align: middle !important;
  }
  #product-table span.status-label {
    display: block;
    width: 85px;
    text-align: center;
    padding: 2px 0px;
  }
  #search-input span.input-group-addon {
    padding: 0;
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 34px;
    border: none;
    background: none;
  }
  #search-input span.input-group-addon i {
    font-size: 18px;
    line-height: 34px;
    width: 34px;
    color: #f30;
  }
  #search-input input {
    position: static;
    width: 100%;
    font-size: 15px;
    line-height: 22px;
    padding: 5px 5px 5px 34px;
    float: none;
    height: unset;
    border-color: #fbfbfb;
    box-shadow: none;
    background-color: #e8f0fe;
    border-radius: 5px;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  <li class="active">Kho Hàng</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- Main row -->
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <div class="row">
            <div class="col-md-5 col-sm-6 col-xs-6">
              <div id="search-input" class="input-group">
                <span class="input-group-addon"><i class="fa fa-search" aria-hidden="true"></i></span>
                <input type="text" class="form-control" placeholder="search...">
              </div>
            </div>
            <div class="col-md-7 col-sm-6 col-xs-6">
              <div class="btn-group pull-right">
                <a href="<?php echo e(route('admin.warehouse')); ?>" class="btn btn-flat btn-primary" title="Refresh" style="margin-right: 5px;">
                  <i class="fa fa-refresh"></i><span class="hidden-xs"> Refresh</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="box-body">
          <table id="product-table" class="table table-hover" style="width:100%; min-width: 985px;">
            <thead>
              <tr>
                <th data-width="10px">STT</th>
                <th data-orderable="false" data-width="75px">Hình Ảnh</th>
                <th data-orderable="false" data-width="85px">Mã Sản Phẩm</th>
                <th data-orderable="false">Tên Sản Phẩm</th>
                <th data-width="90px">Hệ điều hành</th>
                <th data-width="66px">Màu sắc</th>
                <th data-width="100px">Số Lượng Nhập</th>
                <th data-width="66px">Đã Bán</th>
                <th data-width="66px">Còn Lại</th>
                <th data-width="70px" data-type="date-euro">Ngày Nhập</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($product_dt->id); ?></td>
                  <td>
                  <div style="background-image: url('<?php echo e(Helper::get_image_product_url($product_dt->image)); ?>'); padding-top: 100%; background-size: contain; background-repeat: no-repeat; background-position: center;"></div>
                  </td>
                  <td><?php echo e($product_dt->sku_code); ?></td>
                  <td><?php echo e($product_dt->name); ?></td>
                  <td><?php echo e($product_dt->OS); ?></td>
                  <td><?php echo e($product_dt->color); ?></td>
                  <td><?php echo e($product_dt->quantity); ?></td>
                  <td><?php echo e($product_dt->orderDetailQuantity ? $product_dt->orderDetailQuantity : 0); ?></td>
                  <td><?php echo e($product_dt->conlai ? $product_dt->conlai : $product_dt->quantity); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($product_dt->created_at)->format('d/m/Y')); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('embed-js'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
  <script src="https://cdn.datatables.net/plug-ins/1.10.20/sorting/date-euro.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script>
  $(function () {
    var table = $('#product-table').DataTable({
      "language": {
        "zeroRecords":    "Không tìm thấy kết quả phù hợp",
        "info":           "Hiển thị trang <b>_PAGE_/_PAGES_</b> của <b>_TOTAL_</b> sản phẩm",
        "infoEmpty":      "Hiển thị trang <b>1/1</b> của <b>0</b> sản phẩm",
        "infoFiltered":   "(Tìm kiếm từ <b>_MAX_</b> sản phẩm)",
        "emptyTable": "Không có dữ liệu sản phẩm",
      },
      "lengthChange": false,
       "autoWidth": false,
       "order": [],
      "dom": '<"table-responsive"t><<"row"<"col-md-6 col-sm-6"i><"col-md-6 col-sm-6"p>>>',
      "drawCallback": function(settings) {
        var api = this.api();
        if (api.page.info().pages <= 1) {
          $('#'+ $(this).attr('id') + '_paginate').hide();
        }
      }
    });

    $('#search-input input').on('keyup', function() {
        table.search(this.value).draw();
    });
  });

 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/admin/warehouse/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Chỉnh Sửa Hãng'); ?>

<?php $__env->startSection('embed-css'); ?>
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  <li><a href="<?php echo e(route('admin.producer.index')); ?>"><i class="fa fa-sliders" aria-hidden="true"></i> Quản Lý Nhà Sản Xuất</a></li>
  <li class="active">Chỉnh Sửa Quảng Cáo</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div class="callout callout-danger">
    <h4>Warning!</h4>
    <ul style="margin-bottom: 0;">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.producer.update', ['id' => $producer->id])); ?>" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="box box-primary">
    <div class="box-body">
      <div class="row">
        <div class="col-md-9">
          <div class="form-group">
            <label for="title">Tên hãng <span class="text-red">*</span></label>
            <input type="text" name="name" class="form-control" id="title" placeholder="Tên nhà sản xuất" value="<?php echo e(old('name') ?: $producer->name); ?>" autocomplete="off">
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-success btn-flat pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i> Lưu</button>
            <a href="<?php echo e(route('admin.producer.index')); ?>" class="btn btn-danger btn-flat pull-right" style="margin-right: 5px;"><i class="fa fa-ban" aria-hidden="true"></i> Hủy</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('embed-js'); ?>

<!-- date-range-picker -->
<script src="<?php echo e(asset('AdminLTE/bower_components/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('AdminLTE/bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/admin/producer/edit.blade.php ENDPATH**/ ?>
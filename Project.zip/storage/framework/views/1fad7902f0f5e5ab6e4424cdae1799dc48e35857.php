<?php $__env->startSection('title', 'Đăng Nhập'); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('header.Home')); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('header.Login')); ?></li>
      </ol>
    </nav>
  </section>

  <div class="site-login">
      <div class="login-body">
        <h2 class="title">Đăng Nhập</h2>
        <form action="<?php echo e(route('login')); ?>" method="POST" accept-charset="utf-8">
          <?php echo csrf_field(); ?>

          <?php if(session('message')): ?>
            <div class="form_message">
              <?php echo e(session('message')); ?>

            </div>
          <?php endif; ?>

          <div class="input-group">
            <span class="input-group-addon"><i class="fas fa-user"></i></span>
            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="input-group">
            <span class="input-group-addon"><i class="fas fa-lock"></i></span>
            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password" required autocomplete="current-password">

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="login-form-group">
            <div class="row">
              <div class="col-md-6">
                <div class="checkbox">
                  <label><input name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>Remember me</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="forgot-password">
                    <a href="<?php echo e(route('password.request')); ?>" title="Forgot password">Forgot password</a>
                </div>
              </div>
            </div>
          </div>

          <button type="submit" class="btn btn-default">LOGIN</button>
        </form>
      </div>
      <div class="login-social">
        <div class="login-social-text">Or login with</div>
        <div class="row">
          <div class="col-md-6">
            <a href="#" title="Facebook" class="btn btn-defaule"><i class="fab fa-facebook-square"></i> Facebook</a>
          </div>
          <div class="col-md-6">
            <a href="#" title="Google" class="btn btn-defaule"><i class="fab fa-google"></i> Google</a>
          </div>
        </div>
      </div>
      <div class="sign-up-now">
        Not a member? <a href="<?php echo e(route('register')); ?>">Sign up now</a>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){
      <?php if(session('alert')): ?>
        Swal.fire(
          '<?php echo e(session('alert')['title']); ?>',
          '<?php echo e(session('alert')['content']); ?>',
          '<?php echo e(session('alert')['type']); ?>'
        )
      <?php endif; ?>
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/auth/login.blade.php ENDPATH**/ ?>
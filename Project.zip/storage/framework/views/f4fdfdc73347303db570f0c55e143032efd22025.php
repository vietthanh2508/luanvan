<?php $__env->startComponent('mail::message'); ?>
# Xin Chào!
<?php if($data['password']): ?>
Mật khẩu truy cập hệ thống <a href="<?php echo e(route('home_page')); ?>" ><b>VDO</b></a> của bạn là <b><?php echo e($data['password']); ?></b>.<br>Vui lòng click vào button bên dưới để kích hoạt tài khoản. Sau đó thay đổi mật khẩu và cập nhật lại thông tin cá nhân.<br>Xin cảm ơn!
<?php else: ?>
Đây là email kích hoạt tài khoản. Vui lòng click vào button bên dưới để kích hoạt tài khoản.<br>Xin cảm ơn!
<?php endif; ?>
<?php $__env->startComponent('mail::button', ['url' => route('active_account', ['token' => $data['token']])]); ?>
Active Account
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Demo\Project\resources\views/emails/admin/active_account.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Quản Lý Đơn Hàng'); ?>

<?php $__env->startSection('embed-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>
<style>
  #order-table td,
  #order-table th {
    vertical-align: middle !important;
  }
  #order-table span.status-label {
    display: block;
    width: 85px;
    text-align: center;
    padding: 2px 0px;
  }
  #search-input span.input-group-addon {
    padding: 0;
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 34px;
    border: none;
    background: none;
  }
  #search-input span.input-group-addon i {
    font-size: 18px;
    line-height: 34px;
    width: 34px;
    color: #f30;
  }
  #search-input input {
    position: static;
    width: 100%;
    font-size: 15px;
    line-height: 22px;
    padding: 5px 5px 5px 34px;
    float: none;
    height: unset;
    border-color: #fbfbfb;
    box-shadow: none;
    background-color: #e8f0fe;
    border-radius: 5px;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
  <li class="active">Quản Lý Đơn Hàng</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- Main row -->
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <div class="row">
            <div class="col-md-5 col-sm-6 col-xs-6">
              <div id="search-input" class="input-group">
                <span class="input-group-addon"><i class="fa fa-search" aria-hidden="true"></i></span>
                <input type="text" class="form-control" placeholder="search...">
              </div>
            </div>
            <div class="col-md-7 col-sm-6 col-xs-6">
              <div class="btn-group pull-right">
                <a href="<?php echo e(route('admin.order.index')); ?>" class="btn btn-flat btn-primary" title="Refresh">
                  <i class="fa fa-refresh"></i><span class="hidden-xs"> Refresh</span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="box-body">
          <table id="order-table" class="table table-hover" style="width:100%; min-width: 1024px;">
            <thead>
              <tr>
                <th data-width="10px">ID</th>
                <th data-orderable="false" data-width="85px">Mã Đơn Hàng</th>
                <th data-orderable="false" data-width="100px">Tài Khoản</th>
                <th data-orderable="false" data-width="100px">Tên</th>
                <th data-orderable="false">Email</th>
                <th data-orderable="false" data-width="70px">Điện Thoại</th>
                <th data-orderable="false">Phương Thức Thanh Toán</th>
                <th data-width="60px" data-type="date-euro">Ngày Tạo</th>
                <th data-width="66px">Trạng Thái</th>
                <th data-orderable="false" data-width="130px">Tác Vụ</th>
              </tr>
            </thead>
            
            <tbody>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($order->id); ?></td>
                  <td><?php echo e('#'.$order->order_code); ?></td>
                  <td>
                    <a href="<?php echo e(route('admin.user_show', ['id' => $order->user->id])); ?>" class="text-left" title="<?php echo e($order->user->name); ?>"><?php echo e($order->user->name); ?></a>
                  </td>
                  <td><?php echo e($order->name); ?></td>
                  <td><?php echo e($order->email); ?></td>
                  <td><?php echo e($order->phone); ?></td>
                  <td><?php echo e($order->payment_method->name); ?></td>
                  <td> <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d/m/Y')); ?></td>
                  <td>
                
                   <?php if($order->status == 1): ?>
                   <span class="label label-default" style="font-size:13px">Đang Xử Lý</span>
                   <?php elseif($order->status == 2): ?>
                   <span class="label label-info" style="font-size:13px">Đang Vận Chuyển</span>
                   <?php elseif($order->status == 3): ?>
                   <span class="label label-success" style="font-size:13px">Đã Giao Hàng</span>
                   <?php else: ?>
                   <span class="label label-danger" style="font-size:13px">Hủy</span>
                   <?php endif; ?>
                  </td>
                  <td>
                  <div class="btn-group">
                  <button type="button" class="btn btn-success btn-xs" style=" height: 30px;">Action  </button>
                  <button type="button" style="height: 30px;" class="btn btn-success btn-xs dropdown-toggle"
                  data-toggle="dropdown" aria-expanded='false'>
                    <span class="caret"></span>
                    <span class="sr-only">Toggle-dropdown</span>
                    </button>
                  <ul class="dropdown-menu" role="menu">
                    <li>
                      <a href="<?php echo e(route('admin.orderTransaction',['process',$order->id])); ?>"><i class="fa fa-ban"> </i>Đang Vận Chuyển</a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('admin.orderTransaction',['success',$order->id])); ?>" ><i class="fa fa-ban"> </i>Đã Giao Hàng</a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('admin.orderTransaction',['cancel',$order->id])); ?>" ><i class="fa fa-ban"> </i>Hủy</a>
                    </li>
                  </ul>
                    <a href="<?php echo e(route('admin.order.show', ['id' => $order->id])); ?>" class="btn btn-icon btn-sm btn-primary tip" title="Chi Tiết">
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('embed-js'); ?>
  <!-- DataTables -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('AdminLTE/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
  <!-- SlimScroll -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo e(asset('AdminLTE/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
  <script src="https://cdn.datatables.net/plug-ins/1.10.20/sorting/date-euro.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script>
  $(function () {
    var table = $('#order-table').DataTable({
      "language": {
        "zeroRecords":    "Không tìm thấy kết quả phù hợp",
        "info":           "Hiển thị trang <b>_PAGE_/_PAGES_</b> của <b>_TOTAL_</b> đơn hàng",
        "infoEmpty":      "Hiển thị trang <b>1/1</b> của <b>0</b> đơn hàng",
        "infoFiltered":   "(Tìm kiếm từ <b>_MAX_</b> đơn hàng)",
        "emptyTable": "Không có dữ liệu đơn hàng",
      },
      "lengthChange": false,
       "autoWidth": false,
       "order": [],
      "dom": '<"table-responsive"t><<"row"<"col-md-6 col-sm-6"i><"col-md-6 col-sm-6"p>>>',
      "drawCallback": function(settings) {
        var api = this.api();
        if (api.page.info().pages <= 1) {
          $('#'+ $(this).attr('id') + '_paginate').hide();
        }
      }
    });

    $('#search-input input').on('keyup', function() {
        table.search(this.value).draw();
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/admin/order/index.blade.php ENDPATH**/ ?>
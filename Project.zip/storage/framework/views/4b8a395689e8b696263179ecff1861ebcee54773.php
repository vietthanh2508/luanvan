<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
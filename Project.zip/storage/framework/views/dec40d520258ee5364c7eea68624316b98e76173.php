<?php $__env->startSection('title', 'Trang Chủ'); ?>

<?php $__env->startSection('content'); ?>
  <div class="site-home">
    <section class="section-advertise">
      <div class="row">
        <div class="col-md-8">
          <div class="content-advertise">
            <div id="slide-advertise" class="owl-carousel">
              <?php $__currentLoopData = $data['advertises']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide-advertise-inner" style="background-image: url('<?php echo e(Helper::get_image_advertise_url($advertise->image)); ?>');" data-dot="<button><?php echo e($advertise->title); ?></button>"></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="custom-dots-slide-advertises"></div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="new-posts">
            <div class="posts-header">
              <h3 class="posts-title">TIN CÔNG NGHỆ</h3>
            </div>
            <div class="posts-content">
              <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item">
                  <a href="<?php echo e(route('post_page', ['id' => $post->id])); ?>" title="<?php echo e($post->title); ?>">
                    <div class="row">
                      <div class="col-md-4 col-sm-3 col-xs-3 col-xs-responsive">
                        <div class="post-item-image" style="background-image: url('<?php echo e(Helper::get_image_post_url($post->image)); ?>'); padding-top: 50%;"></div>
                      </div>
                      <div class="col-md-8 col-sm-9 col-xs-9 col-xs-responsive">
                        <div class="post-item-content">
                          <h4 class="post-content-title"><?php echo e($post->title); ?></h4>
                          <p class="post-content-date"><?php echo e(date_format($post->created_at, 'h:i A d/m/Y')); ?></p>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section-favorite-products">
      <div class="section-header">
        <h2 class="section-title">SẢN PHẨM ƯA THÍCH</h2>
      </div>
      <div class="section-content">
        <div id="slide-favorite" class="owl-carousel">
          <?php $__currentLoopData = $data['favorite_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($product->rate >= 3.5): ?>
            <div class="item-product">
              <a href="<?php echo e(route('product_page', ['id' => $product->id])); ?>" title="<?php echo e($product->name); ?>">
                <div class="image-product" style="background-image: url('<?php echo e(Helper::get_image_product_url($product->image)); ?>');padding-top: 100%;">
                  <?php echo Helper::get_promotion_percent($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                </div>
                <div class="content-product">
                  <h3 class="title"><?php echo e($product->name); ?></h3>
                  <div class="start-vote">
                  
                    <?php echo Helper::get_start_vote($product->rate); ?>

                  
                  </div>
                  <div class="price">
                    <?php echo Helper::get_real_price($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                  </div>
                </div>
              </a>
            </div>
            <?php endif; ?> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <section class="section-products">
      <div class="section-header">
        <div class="section-header-left">
          <h2 class="section-title">ĐIỆN THOẠI</h2>
        </div>
        <div class="section-header-right">
          <ul>
            <?php $__currentLoopData = $data['producers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('producer_page', ['id' => $producer->id])); ?>" title="<?php echo e($producer->name); ?>"><?php echo e($producer->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
      <div class="section-content">
        <div class="row">
          <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 0): ?>
              <div class="col-md-2 col-md-40">
                <div class="item-product">
                  <a href="<?php echo e(route('product_page', ['id' => $product->id])); ?>" title="<?php echo e($product->name); ?>">
                    <div class="row">
                      <div class="col-md-6 col-sm-6 col-xs-6">
                        <div class="image-product" style="background-image: url('<?php echo e(Helper::get_image_product_url($product->image)); ?>');padding-top: 100%;">
                          <?php echo Helper::get_promotion_percent($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                        </div>
                        <div class="content-product">
                          <h3 class="title"><?php echo e($product->name); ?></h3>
                          <div class="start-vote">
                            <?php echo Helper::get_start_vote($product->rate); ?>

                          </div>
                          <div class="price">
                            <?php echo Helper::get_real_price($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                          </div>
                        </div>
                      </div>
                      <div class="col-md-6 col-sm-6 col-xs-6" style="display: flex;">
                        <div class="product-details">
                          <p><strong><i class="fas fa-tv"></i> Màn Hình: </strong><?php echo e($product->monitor); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera Trước: </strong><?php echo e($product->front_camera); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera sau: </strong><?php echo e($product->rear_camera); ?></p>
                          <p><strong><i class="fas fa-microchip"></i> CPU: </strong><?php echo e($product->CPU); ?></p>
                          <p><strong><i class="fas fa-microchip"></i>GPU: </strong><?php echo e($product->GPU); ?></p>
                          <p><strong><i class="fas fa-hdd"></i> RAM: </strong><?php echo e($product->RAM); ?>GB</p>
                          <p><strong><i class="fas fa-hdd"></i> Bộ Nhớ Trong: </strong><?php echo e($product->ROM); ?>GB</p>
                          <?php if(Str::is('*Android*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-android"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*IOS*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-apple"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*Windows*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-windows"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php endif; ?>
                          <p><strong><i class="fas fa-battery-full"></i> Dung Lượng PIN: </strong><?php echo e($product->pin); ?></p>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            <?php else: ?>
              <div class="col-md-2 col-md-20">
                <div class="item-product">
                  <a href="<?php echo e(route('product_page', ['id' => $product->id])); ?>" title="<?php echo e($product->name); ?>">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="image-product" style="background-image: url('<?php echo e(Helper::get_image_product_url($product->image)); ?>');padding-top: 100%;">
                          <?php echo Helper::get_promotion_percent($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                        </div>
                        <div class="content-product">
                          <h3 class="title"><?php echo e($product->name); ?></h3>
                          <div class="start-vote">
                            <?php echo Helper::get_start_vote($product->rate); ?>

                          </div>
                          <div class="price">
                            <?php echo Helper::get_real_price($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-xs-12 animate">
                        <div class="product-details">
                          <p><strong><i class="fas fa-tv"></i> Màn Hình: </strong><?php echo e($product->monitor); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera Trước: </strong><?php echo e($product->front_camera); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera sau: </strong><?php echo e($product->rear_camera); ?></p>
                          <p><strong><i class="fas fa-microchip"></i> CPU: </strong><?php echo e($product->CPU); ?></p>
                          <p><strong><i class="fas fa-microchip"></i>GPU: </strong><?php echo e($product->GPU); ?></p>
                          <p><strong><i class="fas fa-hdd"></i> RAM: </strong><?php echo e($product->RAM); ?>GB</p>
                          <p><strong><i class="fas fa-hdd"></i> Bộ Nhớ Trong: </strong><?php echo e($product->ROM); ?>GB</p>
                          <?php if(Str::is('*Android*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-android"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*IOS*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-apple"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*Windows*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-windows"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php endif; ?>
                          <p><strong><i class="fas fa-battery-full"></i> Dung Lượng PIN: </strong><?php echo e($product->pin); ?></p>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>

  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){
      $("#slide-advertise").owlCarousel({
        items: 1,
        autoplay: true,
        autoplayHoverPause: true,
        loop: true,
        nav: true,
        dots: true,
        dotsData: true,
        responsive:{
          0:{
            nav:false,
            dots: false
          },
          641:{
            nav:true,
            dots: true
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>'],
        dotsContainer: '.custom-dots-slide-advertises'
      });

      $("#slide-favorite").owlCarousel({
        items: 5,
        autoplay: true,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        responsive:{
          0:{
              items:1,
              nav:false
          },
          480:{
              items:2,
              nav:false
          },
          769:{
              items:3,
              nav:true
          },
          992:{
              items:4,
              nav:true,
          },
          1200:{
              items:5,
              nav:true
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>']
      });

      <?php if(session('alert')): ?>
        Swal.fire(
          '<?php echo e(session('alert')['title']); ?>',
          '<?php echo e(session('alert')['content']); ?>',
          '<?php echo e(session('alert')['type']); ?>'
        )
      <?php endif; ?>
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Lập Trình Web PHP NC\XAMPP_25_11\PhoneStore_L9\resources\views/pages/home.blade.php ENDPATH**/ ?>
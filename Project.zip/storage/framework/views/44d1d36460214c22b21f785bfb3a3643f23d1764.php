<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title> <?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?> </title>
  <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/png">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

  <!-- Embed CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('common/css/normalize.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/bootstrap-theme.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/fontawesome/css/all.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/owl.theme.default.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('common/css/sweetalert2.min.css')); ?>">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <?php if(Request::route()->getName() != 'show_cart'): ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/minicart.css')); ?>">
  <?php endif; ?>
  <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <!-- Load Facebook SDK for JavaScript -->
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v4.0'
        });
      };

      (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

    <!-- Your customer chat code -->
    <div class="fb-customerchat"
      attribution=setup_tool
      page_id="106507137419133"
      theme_color="#ff3300"
      logged_in_greeting="<?php echo e(__('message.welcome')); ?>"
      logged_out_greeting="<?php echo e(__('message.welcome')); ?>">
    </div>

    <!-- Header -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
      <!-- Site Content -->
      <div class="site-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>

    <?php if(Request::route()->getName() != 'show_cart'): ?>
    <!-- MiniCart display -->
    <?php echo $__env->make('layouts.minicart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Embed Scripts -->
    <script src="<?php echo e(asset('common/js/jquery-3.3.1.js')); ?>"></script>
    <script src="<?php echo e(asset('common/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('common/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('common/js/sweetalert2.min.js')); ?>"></script>

    <!-- Custom Scripts -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <?php if(Request::route()->getName() != 'show_cart'): ?>
    <script src="<?php echo e(asset('js/minicart.js')); ?>"></script>
    <?php endif; ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH D:\Lập Trình Web PHP NC\XAMPP_25_11\PhoneStore_L9\resources\views/layouts/master.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Thay Đổi Thông Tin'); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('Trang Chủ')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('show_user')); ?>">Tài Khoản</a></li>
        <li class="breadcrumb-item active" aria-current="page">Thay Đổi Thông Tin</li>
      </ol>
    </nav>
  </section>

  <div class="site-user">
    <section class="section-advertise">
      <div class="content-advertise">
        <div id="slide-advertise" class="owl-carousel">
          <?php $__currentLoopData = $data['advertises']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide-advertise-inner" style="background-image: url('<?php echo e(Helper::get_image_advertise_url($advertise->image)); ?>');" data-dot="<button><?php echo e($advertise->title); ?></button>"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

    <section class="section-user">
      <div class="section-header">
        <h2 class="section-title">Thông Tin Tài Khoản</h2>
      </div>
      <div class="section-content">
        <div class="row">
          <div class="col-md-9">
            <div class="user">
              <form class="form-user" action="<?php echo e(route('save_user')); ?>" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_id" value="<?php echo e($data['user']->id); ?>">
                <div class="row">
                  <div class="col-md-3 col-sm-4 col-xs-4">
                    <div class="upload-avatar">
                      <div title="Avatar Preview" class="avatar-preview" style="background-image: url('<?php echo e(Helper::get_image_avatar_url($data['user']->avatar_image)); ?>'); padding-top: 100%;"></div>
                      <label for="upload" title="Upload Avatar"><i class="fas fa-folder-open"></i> Upload Avatar</label>
                      <input type="file" accept="image/*" id="upload" style="display:none" name="avatar_image">
                    </div>
                  </div>
                  <div class="col-md-9 col-sm-8 col-xs-8">
                    <div class="user-info">
                      <div class="info">
                        <div class="info-label">Tên Tài Khoản</div>
                        <div class="info-content">
                          <input id="name" type="text" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" placeholder="Name" value="<?php echo e(old('name') ?: $data['user']->name); ?>" required autocomplete="name" autofocus>

                          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                            </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="info">
                        <div class="info-label">Email</div>
                        <div class="info-content">
                          <input type="email" name="email" placeholder="Email" value="<?php echo e($data['user']->email); ?>" disabled="true">
                        </div>
                      </div>
                      <div class="info">
                        <div class="info-label">Số Điện Thoại</div>
                        <div class="info-content">
                          <input id="phone" type="tel" class="<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" placeholder="Phone" value="<?php echo e(old('phone') ?: $data['user']->phone); ?>" required autocomplete="phone">

                          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                            </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="info">
                        <div class="info-label">Địa Chỉ</div>
                        <div class="info-content">
                          <textarea name="address" class="<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" required><?php echo e(old('address') ?: $data['user']->address); ?></textarea>

                          <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                            </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="action-edit">
                      <button type="submit" class="btn btn-default" title="Lưu Thay Đổi">Lưu Thay Đổi</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-3">
            <div class="online_support">
              <h2 class="title">CHÚNG TÔI LUÔN SẴN SÀNG<br>ĐỂ GIÚP ĐỠ BẠN</h2>
              <img src="<?php echo e(asset('images/support_online.jpg')); ?>">
              <h3 class="sub_title">Để được hỗ trợ tốt nhất. Hãy gọi</h3>
              <div class="phone">
                <a href="tel:18006750" title="1800 6750">1800 6750</a>
              </div>
              <div class="or"><span>HOẶC</span></div>
              <h3 class="title">Chat hỗ trợ trực tuyến</h3>
              <h3 class="sub_title">Chúng tôi luôn trực tuyến 24/7.</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>
    .slide-advertise-inner {
      background-repeat: no-repeat;
      background-size: cover;
      padding-top: 21.25%;
    }
    #slide-advertise.owl-carousel .owl-item.active {
      -webkit-animation-name: zoomIn;
      animation-name: zoomIn;
      -webkit-animation-duration: .6s;
      animation-duration: .6s;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){

      $("#slide-advertise").owlCarousel({
        items: 2,
        autoplay: true,
        loop: true,
        margin: 10,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        responsive:{
          0:{
            items: 1,
          },
          992:{
            items: 2,
            animateOut: 'zoomInRight',
            animateIn: 'zoomOutLeft',
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>']
      });

      $("#upload").change(function() {
        $('.site-user .upload-avatar .avatar-preview').css('background-image', 'url("' + getImageURL(this) + '")');
      });

      <?php if(session('alert')): ?>
        Swal.fire(
          '<?php echo e(session('alert')['title']); ?>',
          '<?php echo e(session('alert')['content']); ?>',
          '<?php echo e(session('alert')['type']); ?>'
        )
      <?php endif; ?>
    });

    function getImageURL(input) {
      return URL.createObjectURL(input.files[0]);
    };
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/pages/edit_user.blade.php ENDPATH**/ ?>
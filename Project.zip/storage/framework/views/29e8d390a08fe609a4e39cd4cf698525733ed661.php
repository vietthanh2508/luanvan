<?php $__env->startSection('title', 'Tìm Kiếm'); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('Trang Chủ')); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page">Tìm Kiếm: <?php echo e(Request::get('search_key')); ?></li>
      </ol>
    </nav>
  </section>

  <div class="site-search">
    <section class="section-advertise">
      <div class="content-advertise">
        <div id="slide-advertise" class="owl-carousel">
          <?php $__currentLoopData = $data['advertises']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide-advertise-inner" style="background-image: url('<?php echo e(Helper::get_image_advertise_url($advertise->image)); ?>');" data-dot="<button><?php echo e($advertise->title); ?></button>"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

    <section class="section-products">
      <div class="section-header">
        <h2 class="section-title">Sản Phẩm <span>( <?php echo e($data['products']->count()); ?> sản phẩm )</span></h2>
      </div>
      <div class="section-content">
        <?php if($data['products']->isEmpty()): ?>
          <div class="empty-content">
            <div class="icon"><i class="fab fa-searchengin"></i></div>
            <div class="title">Oooops!</div>
            <div class="content">Product Item Not Found</div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-2 col-md-20">
                <div class="item-product">
                  <a href="<?php echo e(route('product_page', ['id' => $product->id])); ?>" title="<?php echo e($product->name); ?>">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="image-product" style="background-image: url('<?php echo e(Helper::get_image_product_url($product->image)); ?>');padding-top: 100%;">
                          <?php echo Helper::get_promotion_percent($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                        </div>
                        <div class="content-product">
                          <h3 class="title"><?php echo e($product->name); ?></h3>
                          <div class="start-vote">
                            <?php echo Helper::get_start_vote($product->rate); ?>

                          </div>
                          <div class="price">
                            <?php echo Helper::get_real_price($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 col-sm-12 col-xs-12 animate">
                        <div class="product-details">
                          <p><strong><i class="fas fa-tv"></i> Màn Hình: </strong><?php echo e($product->monitor); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera Trước: </strong><?php echo e($product->front_camera); ?></p>
                          <p><strong><i class="fas fa-camera-retro"></i> Camera sau: </strong><?php echo e($product->rear_camera); ?></p>
                          <p><strong><i class="fas fa-microchip"></i> CPU: </strong><?php echo e($product->CPU); ?></p>
                          <p><strong><i class="fas fa-microchip"></i>GPU: </strong><?php echo e($product->GPU); ?></p>
                          <p><strong><i class="fas fa-hdd"></i> RAM: </strong><?php echo e($product->RAM); ?>GB</p>
                          <p><strong><i class="fas fa-hdd"></i> Bộ Nhớ Trong: </strong><?php echo e($product->ROM); ?>GB</p>
                          <?php if(Str::is('*Android*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-android"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*IOS*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-apple"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php elseif(Str::is('*Windows*', $product->OS_version)): ?>
                            <p><strong><i class="fab fa-windows"></i> HĐH: </strong><?php echo e($product->OS_version); ?></p>
                          <?php endif; ?>
                          <p><strong><i class="fas fa-battery-full"></i> Dung Lượng PIN: </strong><?php echo e($product->pin); ?></p>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <section class="section-posts">
      <div class="section-header">
        <h2 class="section-title">Bài viết <span>( <?php echo e($data['posts']->count()); ?> bài viết )</span></h2>
      </div>
      <div class="section-content">
        <?php if($data['posts']->isEmpty()): ?>
          <div class="empty-content">
            <div class="icon"><i class="fab fa-searchengin"></i></div>
            <div class="title">Oooops!</div>
            <div class="content">Posts Item Not Found</div>
          </div>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3 col-sm-4 col-xs-6">
                <div class="item-post">
                  <a href="<?php echo e(route('post_page', ['id' => $post->id])); ?>" title="<?php echo e($post->title); ?>">
                    <div class="image-post" style="background-image: url('<?php echo e(Helper::get_image_post_url($post->image)); ?>');padding-top: 50%;">
                    </div>
                    <div class="title-post">
                      <h3><?php echo e($post->title); ?></h3>
                    </div>
                    <div class="date-post">
                      Ngày đăng: <?php echo e(date_format($post->created_at, 'd/m/Y')); ?>

                    </div>
                  </a>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>
    .slide-advertise-inner {
      background-repeat: no-repeat;
      background-size: cover;
      padding-top: 21.25%;
    }
    #slide-advertise.owl-carousel .owl-item.active {
      -webkit-animation-name: zoomIn;
      animation-name: zoomIn;
      -webkit-animation-duration: .6s;
      animation-duration: .6s;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){

      $("#slide-advertise").owlCarousel({
        items: 2,
        autoplay: true,
        loop: true,
        margin: 10,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        responsive:{
          0:{
            items: 1,
          },
          992:{
            items: 2,
            animateOut: 'zoomInRight',
            animateIn: 'zoomOutLeft',
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>']
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/pages/search.blade.php ENDPATH**/ ?>
<header id="header" class="header">
  <div class="container">
    <div class="row display-flex">
      <div class="col-md-2 margin-auto trigger-menu">

        <button type="button" class="navbar-toggle collapsed visible-xs" id="trigger-mobile">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>

        <div class="logo">
          <a class="logo-wrapper" href="<?php echo e(route('home_page')); ?>" title="<?php echo e(config('app.name')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>"></a>
        </div>
      </div>
      <div class="col-md-3 margin-auto">
        <div class="search">
          <form class="search-bar" action="<?php echo e(route('search')); ?>" method="get" accept-charset="utf-8">
            <input class="input-search" type="search" name="search_key" placeholder="<?php echo e(__('Tìm Kiếm')); ?>" autocomplete="off">
            <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>
      </div>
      <div class="col-md-8 hd-bg-white main-menu-responsive">
        <div class="main-menu">
          <div class="nav">
            <ul>
              <li class="nav-item <?php echo e(Helper::check_active(['home_page'])); ?>"><a href="<?php echo e(route('home_page')); ?>" title="<?php echo e(__('Trang Chủ')); ?>">
                <span class="fas fa-home"></span>
                <?php echo e(__('Trang Chủ')); ?></a>
              </li>
              <li class="nav-item <?php echo e(Helper::check_active(['about_page'])); ?>"><a href="<?php echo e(route('about_page')); ?>" title="<?php echo e(__('Giới Thiệu')); ?>">
                <span class="fas fa-info"></span>
                <?php echo e(__('Giới Thiệu')); ?></a>
              </li>
              <li class="nav-item dropdown <?php echo e(Helper::check_active(['products_page', 'producer_page', 'product_page'])); ?>">
                <a href="<?php echo e(route('products_page')); ?>" title="<?php echo e(__('Sản Phẩm')); ?>">
                  <span class="fas fa-mobile-alt"></span>
                  <?php echo e(__('Sản Phẩm')); ?> <i class="fas fa-angle-down"></i>
                </a>
                <div class="dropdown-menu">
                  <ul class="dropdown-menu-item">
                    <li>
                      <h4><?php echo e(__('Danh Mục')); ?></h4>
                      <ul class="dropdown-menu-subitem">
                        <?php $__currentLoopData = $producers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="<?php echo e(Helper::check_param_active('producer_page', $producer->id)); ?>"><a href="<?php echo e(route('producer_page', ['id' => $producer->id])); ?>" title="<?php echo e($producer->name); ?>"><?php echo e($producer->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item <?php echo e(Helper::check_active(['posts_page', 'post_page'])); ?>"><a href="<?php echo e(route('posts_page')); ?>" title="<?php echo e(__('Tin Tức')); ?>">
                <span class="far fa-newspaper"></span>
                <?php echo e(__('Tin Tức')); ?></a>
              </li>
              <li class="nav-item <?php echo e(Helper::check_active(['contact_page'])); ?>"><a href="<?php echo e(route('contact_page')); ?>" title="<?php echo e(__('Liên Hệ')); ?>">
                <span class="fas fa-id-card"></span>
                <?php echo e(__('Liên Hệ')); ?></a>
              </li><li class="nav-item <?php echo e(Helper::check_active(['contact_page'])); ?>"><a href="<?php echo e(route('show_cart')); ?>" title="<?php echo e(__('Giỏ Hàng')); ?>">
                <span class="fa fa-shopping-cart"></span>
                <?php echo e(__('Giỏ Hàng')); ?></a>
              </li>
            </ul>
          </div>
          <div class="accout-menu">
            <?php if(Auth::guest()): ?>
              <div class="not-logged-menu">
                <ul>
                  <li class="menu-item <?php echo e(Helper::check_active(['login'])); ?>"><a href="<?php echo e(route('login')); ?>" title="<?php echo e(__('Đăng Nhập')); ?>">
                    <span class="fas fa-user"></span>
                    <?php echo e(__('Đăng Nhập')); ?></a>
                  </li>
                  <li class="menu-item <?php echo e(Helper::check_active(['register'])); ?>"><a href="<?php echo e(route('register')); ?>" title="<?php echo e(__('Đăng Ký')); ?>">
                    <span class="fas fa-key"></span>
                    <?php echo e(__('Đăng Ký')); ?></a>
                  </li>
                </ul>
              </div>
            <?php else: ?>
              <div class="logged-menu">
                <ul>
                  <li class="menu-item dropdown <?php echo e(Helper::check_active(['orders_page', 'order_page', 'show_user', 'edit_user'])); ?>">
                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" title="<?php echo e(Auth::user()->name); ?>">
                      <div class="avatar" style="background-image: url('<?php echo e(Helper::get_image_avatar_url(Auth::user()->avatar_image)); ?>');"></div>
                    </a>
                    <ul class="dropdown-menu">
                      <?php if(Auth::user()->admin): ?>
                      <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Quản Lý Website</a></li>
                      <?php else: ?>
                      <li class="<?php echo e(Helper::check_active(['orders_page', 'order_page'])); ?>"><a href="<?php echo e(route('orders_page')); ?>"><i class="fas fa-clipboard-list"></i> Quản Lý Đơn Hàng</a></li>
                      <li class="<?php echo e(Helper::check_active(['show_user', 'edit_user'])); ?>"><a href="<?php echo e(route('show_user')); ?>"><i class="fas fa-user-cog"></i> Quản Lý Tài Khoản</a></li>
                      <?php endif; ?>
                      <li><a id="logout" action="#"><i class="fas fa-power-off"></i> <?php echo e(__('Đăng Xuất')); ?></a></li>
                    </ul>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                  </li>
                </ul>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</header><!-- /header -->


<?php /**PATH E:\Programs\Xampp\htdocs\Project\resources\views/layouts/header.blade.php ENDPATH**/ ?>
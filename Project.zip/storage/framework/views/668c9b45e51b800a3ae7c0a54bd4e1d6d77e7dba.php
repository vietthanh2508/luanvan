<?php $__env->startSection('title', $data['post']->title); ?>

<?php $__env->startSection('content'); ?>

  <section class="bread-crumb">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home_page')); ?>"><?php echo e(__('Trang Chủ')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('posts_page')); ?>">Tin Tức</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($data['post']->title); ?></li>
      </ol>
    </nav>
  </section>

  <div class="site-post">
    <section class="section-advertise">
      <div class="content-advertise">
        <div id="slide-advertise" class="owl-carousel">
          <?php $__currentLoopData = $data['advertises']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide-advertise-inner" style="background-image: url('<?php echo e(Helper::get_image_advertise_url($advertise->image)); ?>');" data-dot="<button><?php echo e($advertise->title); ?></button>"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

    <section class="section-post">
      <div class="row">
        <div class="col-md-8">
          <div class="section-left">
            <div class="section-header">
              <h2 class="section-title">Bài Viết</h2>
            </div>
            <div class="section-content">
              <div class="header-post">
                <div class="image-post" style="background-image: url('<?php echo e(Helper::get_image_post_url($data['post']->image)); ?>'); padding-top: 50%;"></div>
                <div class="info-post">
                  <div class="title-post"><h3><?php echo e($data['post']->title); ?></h3></div>
                  <div class="desc-post">
                    <span><i class="fas fa-user"></i> Admin</span>
                    <span><i class="fas fa-clock"></i> <?php echo e(date_format($data['post']->created_at, 'd/m/Y')); ?></span>
                  </div>
                </div>
              </div>
              <div class="content-post">
                <div class="content-inner">
                  <?php echo $data['post']->content; ?>

                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="section-right">
            <div class="suggest-post">
              <div class="suggest-header">
                <h2>Bài Viết Mới</h2>
              </div>
              <?php if($data['suggest_posts']->isNotEmpty()): ?>
                <div class="suggest-content">
                  <?php $__currentLoopData = $data['suggest_posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('post_page', ['id' => $post->id])); ?>" title="<?php echo e($post->title); ?>">
                      <div class="post-content">
                        <div class="image">
                          <img src="<?php echo e(Helper::get_image_post_url($post->image)); ?>">
                        </div>
                        <div class="content">
                          <h3 class="title"><?php echo e($post->title); ?></h3>
                          <div class="desc">
                            <span><i class="fas fa-user"></i> Admin</span>
                            <span><i class="fas fa-clock"></i> <?php echo e(date_format($post->created_at, 'd/m/Y')); ?></span>
                          </div>
                        </div>
                      </div>
                    </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
            </div>

            <div class="suggest-product">
              <div class="suggest-header">
                <h2>Sản Phẩm Mới Nhất</h2>
              </div>
              <?php if($data['suggest_products']->isNotEmpty()): ?>
                <div class="suggest-content">
                  <?php $__currentLoopData = $data['suggest_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('product_page', ['id' => $product->id])); ?>" title="<?php echo e($product->name); ?>">
                      <div class="product-content">
                        <div class="image">
                          <img src="<?php echo e(Helper::get_image_product_url($product->image)); ?>">
                        </div>
                        <div class="content">
                          <h3 class="title"><?php echo e($product->name); ?></h3>
                          <div class="start-vote">
                            <?php echo Helper::get_start_vote($product->rate); ?>

                          </div>
                          <div class="price">
                            <?php echo Helper::get_real_price($product->product_detail->sale_price, $product->product_detail->promotion_price, $product->product_detail->promotion_start_date, $product->product_detail->promotion_end_date); ?>

                          </div>
                        </div>
                      </div>
                    </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>
    .slide-advertise-inner {
      background-repeat: no-repeat;
      background-size: cover;
      padding-top: 21.25%;
    }
    #slide-advertise.owl-carousel .owl-item.active {
      -webkit-animation-name: zoomIn;
      animation-name: zoomIn;
      -webkit-animation-duration: .6s;
      animation-duration: .6s;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){

      $("#slide-advertise").owlCarousel({
        items: 2,
        autoplay: true,
        loop: true,
        margin: 10,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        responsive:{
          0:{
            items: 1,
          },
          992:{
            items: 2,
            animateOut: 'zoomInRight',
            animateIn: 'zoomOutLeft',
          }
        },
        navText: ['<i class="fas fa-angle-left"></i>', '<i class="fas fa-angle-right"></i>']
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PHP_Laravel\PhoneStore_L9\resources\views/pages/post.blade.php ENDPATH**/ ?>